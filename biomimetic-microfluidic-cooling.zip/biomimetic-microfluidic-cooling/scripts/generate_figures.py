# ============================================================
# Google Colab / Local Script – Generate all 8 figures
# for the paper "Biomimetic Microfluidic Cooling..."
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Circle, Rectangle
import seaborn as sns
from PIL import Image, ImageDraw
import os

os.makedirs("paper_figures", exist_ok=True)

sns.set_style("whitegrid")
plt.rcParams.update({
    "font.size": 12,
    "axes.labelsize": 13,
    "axes.titlesize": 14,
    "legend.fontsize": 11,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "font.family": "DejaVu Sans"
})

# ------------------------------------------------------------
# 1. Viscosity vs Temperature + LCST model
# ------------------------------------------------------------
T = np.array([25, 35, 50, 60, 70, 80, 90])
mu = np.array([420, 410, 360, 240, 155, 95, 72])

def mu_model(T):
    mu0, mu_inf = 420, 15
    T_LCST, dT, A = 72, 8, 160
    background = mu_inf + (mu0 - mu_inf) * np.exp(-0.025*(T-25))
    lcst = -A * np.tanh((T - T_LCST)/dT)
    return background + lcst

T_fine = np.linspace(20, 95, 300)
mu_fit = mu_model(T_fine)

fig, ax = plt.subplots(figsize=(8, 5.5))
ax.plot(T, mu, "o", markersize=9, color="#1f77b4", label="Experimental data", zorder=5)
ax.plot(T_fine, mu_fit, "-", linewidth=2.5, color="#d62728", label="LCST model (Eq. 1–2)")
ax.axvspan(65, 85, alpha=0.15, color="orange", label="Strong LCST region")
ax.set_xlabel("Temperature (°C)")
ax.set_ylabel("Viscosity (mPa·s)")
ax.set_title("Viscosity–Temperature Behaviour of 2 % Methylcellulose\nin [P$_{6,6,6,14}$][TFSI]")
ax.legend(loc="upper right")
ax.set_xlim(20, 95)
ax.set_ylim(0, 460)
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("paper_figures/Fig1_Viscosity_vs_T.png")
plt.close()
print("✓ Saved: Fig1_Viscosity_vs_T.png")

# ------------------------------------------------------------
# 2. Power-output sensitivity
# ------------------------------------------------------------
dT = np.array([20, 30, 40, 45, 50, 60])
P = np.array([4.7, 10.5, 18.7, 23.6, 29.2, 42.1])
p_density = np.array([0.47, 1.05, 1.87, 2.36, 2.92, 4.21])

fig, ax1 = plt.subplots(figsize=(8, 5))
color1 = "#2ca02c"
ax1.plot(dT, P, "s-", markersize=8, linewidth=2.2, color=color1, label="Power (mW)")
ax1.set_xlabel("Temperature difference ΔT (K)")
ax1.set_ylabel("Power output (mW)", color=color1)
ax1.tick_params(axis="y", labelcolor=color1)
ax1.set_ylim(0, 50)

ax2 = ax1.twinx()
color2 = "#9467bd"
ax2.plot(dT, p_density, "D--", markersize=8, linewidth=2.2, color=color2, label="Power density (mW cm$^{-2}$)")
ax2.set_ylabel("Power density (mW cm$^{-2}$)", color=color2)
ax2.tick_params(axis="y", labelcolor=color2)
ax2.set_ylim(0, 5)

ax1.axvline(45, color="gray", linestyle=":", alpha=0.7)
ax1.annotate("Design point\n(ΔT = 45 K)", xy=(45, 23.6), xytext=(52, 35),
             arrowprops=dict(arrowstyle="->", color="gray"), fontsize=10)

fig.legend(loc="upper left", bbox_to_anchor=(0.12, 0.88))
ax1.set_title("Thermogalvanic Power Output Sensitivity")
ax1.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("paper_figures/Fig2_Power_Sensitivity.png")
plt.close()
print("✓ Saved: Fig2_Power_Sensitivity.png")

# ------------------------------------------------------------
# 3. Response-time comparison
# ------------------------------------------------------------
labels = ["Passive system\n(this work)", "Conventional\nSCADA"]
times = [150, 500]
colors = ["#2ca02c", "#d62728"]

fig, ax = plt.subplots(figsize=(7, 5))
bars = ax.bar(labels, times, color=colors, width=0.55, edgecolor="black", linewidth=1.2)
ax.set_ylabel("Response time (ms)")
ax.set_title("Thermal Response Time Comparison")
ax.set_ylim(0, 650)

for bar, t in zip(bars, times):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 15,
            f"{t} ms", ha="center", va="bottom", fontweight="bold", fontsize=12)

ax.annotate("≈ 3.3× faster", xy=(0.5, 320), xytext=(0.5, 420),
            ha="center", arrowprops=dict(arrowstyle="<->", color="black", lw=1.5),
            fontsize=11, fontweight="bold")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig("paper_figures/Fig3_Response_Time.png")
plt.close()
print("✓ Saved: Fig3_Response_Time.png")

# ------------------------------------------------------------
# 4. Thermal-resistance network diagram
# ------------------------------------------------------------
fig, ax = plt.subplots(figsize=(10, 4))
ax.set_xlim(0, 10)
ax.set_ylim(0, 4)
ax.axis("off")
ax.set_title("Thermal Resistance Network (Die → Coolant)", fontsize=14, pad=15)

boxes = [
    (0.5, 1.5, 1.8, 1.0, "GPU Die\n$R_{die}=0.003$ K/W", "#aec7e8"),
    (3.0, 1.5, 1.8, 1.0, "TIM\n$R_{TIM}=0.0027$ K/W", "#ffbb78"),
    (5.5, 1.5, 2.2, 1.0, "Convection\n$R_{conv}=0.116$ K/W", "#98df8a"),
    (8.3, 1.5, 1.4, 1.0, "Bulk\nCoolant", "#c5b0d5"),
]

for x, y, w, h, text, color in boxes:
    rect = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05",
                          facecolor=color, edgecolor="black", linewidth=1.5)
    ax.add_patch(rect)
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=10)

for x in [2.3, 4.8, 7.7]:
    ax.annotate("", xy=(x+0.2, 2.0), xytext=(x, 2.0),
                arrowprops=dict(arrowstyle="->", color="black", lw=2))

ax.text(5, 0.6, r"$R_{\rm total}=0.122$ K/W  →  $\Delta T \approx 12.2$ °C at 100 W",
        ha="center", fontsize=12, fontweight="bold",
        bbox=dict(boxstyle="round", facecolor="lightyellow", edgecolor="gray"))
plt.tight_layout()
plt.savefig("paper_figures/Fig4_Thermal_Resistance.png")
plt.close()
print("✓ Saved: Fig4_Thermal_Resistance.png")

# ------------------------------------------------------------
# 5. Microfluidic channel schematic
# ------------------------------------------------------------
fig, ax = plt.subplots(figsize=(9, 5))
ax.set_xlim(0, 12)
ax.set_ylim(0, 6)
ax.axis("off")
ax.set_title("Microfluidic Channel Geometry (8 parallel channels)", fontsize=14, pad=10)

ax.add_patch(Rectangle((1, 1), 10, 4, fill=False, edgecolor="black", linewidth=2))

for i in range(8):
    y = 1.3 + i * 0.45
    ax.add_patch(Rectangle((1.5, y), 9, 0.25, facecolor="#1f77b4", edgecolor="navy", alpha=0.7))

ax.text(6, 5.3, "Inlet manifold", ha="center", fontsize=11)
ax.text(6, 0.5, "Outlet manifold", ha="center", fontsize=11)
ax.annotate("", xy=(1.3, 3), xytext=(0.5, 3),
            arrowprops=dict(arrowstyle="->", color="green", lw=2))
ax.text(0.3, 3.3, "Flow", fontsize=10, color="green")

ax.annotate("", xy=(1.5, 0.9), xytext=(10.5, 0.9),
            arrowprops=dict(arrowstyle="<->", color="black"))
ax.text(6, 0.6, "L = 50 mm", ha="center", fontsize=10)

ax.annotate("", xy=(11.2, 1.3), xytext=(11.2, 4.7),
            arrowprops=dict(arrowstyle="<->", color="black"))
ax.text(11.5, 3, "8 × H = 150 µm\nW = 500 µm", va="center", fontsize=9)

ax.text(6, 5.7, r"$D_h = 188$ µm   |   Re ≈ 2.1 (laminar)   |   ΔP ≈ 0.014 bar",
        ha="center", fontsize=11,
        bbox=dict(boxstyle="round", facecolor="lightyellow"))
plt.tight_layout()
plt.savefig("paper_figures/Fig5_Microfluidic_Geometry.png")
plt.close()
print("✓ Saved: Fig5_Microfluidic_Geometry.png")

# ------------------------------------------------------------
# 6. LCST molecular mechanism illustration
# ------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(11, 5))
fig.suptitle("Methylcellulose LCST Mechanism", fontsize=15, fontweight="bold")

ax = axes[0]
ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.axis("off")
ax.set_title("Below LCST (T < 70 °C)\nExtended, H-bonded chains\nHigh viscosity (~420 mPa·s)", fontsize=12)

for i, y in enumerate([2, 4, 6, 8]):
    xs = np.linspace(1, 9, 40)
    ys = y + 0.4*np.sin(xs*1.5 + i)
    ax.plot(xs, ys, color="#1f77b4", lw=2.5)
    if i < 3:
        ax.plot([3, 4], [y+0.3, y+1.7], "k--", alpha=0.5, lw=1)
        ax.plot([6, 7], [y+0.3, y+1.7], "k--", alpha=0.5, lw=1)

ax.text(5, 0.5, "Polymer network + solvent\n→ high viscosity", ha="center", fontsize=11,
        bbox=dict(boxstyle="round", facecolor="#c6dbef"))

ax = axes[1]
ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.axis("off")
ax.set_title("Above LCST (T > 75 °C)\nCollapsed hydrophobic coils\nLow viscosity (~95 mPa·s)", fontsize=12)

centers = [(3, 3), (7, 3), (3, 7), (7, 7), (5, 5)]
for cx, cy in centers:
    circle = Circle((cx, cy), 1.1, facecolor="#ff7f0e", edgecolor="#d62728", alpha=0.8, lw=2)
    ax.add_patch(circle)
    ax.plot(cx, cy, "o", color="white", markersize=4)

ax.text(5, 0.5, "Hydrophobic collapse\n→ low viscosity", ha="center", fontsize=11,
        bbox=dict(boxstyle="round", facecolor="#fdd0a2"))

plt.tight_layout()
plt.savefig("paper_figures/Fig6_LCST_Mechanism.png")
plt.close()
print("✓ Saved: Fig6_LCST_Mechanism.png")

# ------------------------------------------------------------
# 7. Gantt-style timeline
# ------------------------------------------------------------
tasks = [
    ("Materials procurement", 1, 4),
    ("Microfluidic design & photolithography", 2, 5),
    ("PDMS fabrication & bonding", 3, 6),
    ("Cold-plate CNC & assembly", 2, 4),
    ("Fluid preparation & characterisation", 3, 5),
    ("Thermocell electrode preparation", 4, 5),
    ("System integration & pressure test", 5, 6),
    ("Thermal-response measurement", 7, 10),
    ("Power-output validation", 8, 11),
    ("Long-term stability testing", 11, 13),
    ("Data analysis & manuscript", 12, 16),
]

fig, ax = plt.subplots(figsize=(11, 6.5))
colors = plt.cm.tab20(np.linspace(0, 1, len(tasks)))

for i, (name, start, end) in enumerate(tasks):
    ax.barh(i, end-start+0.1, left=start-0.05, height=0.6,
            color=colors[i], edgecolor="black", linewidth=0.8)
    ax.text(start-0.2, i, name, ha="right", va="center", fontsize=10)

ax.set_yticks([])
ax.set_xlabel("Week number")
ax.set_xlim(0, 17)
ax.set_title("16-Week Prototype Development Timeline", fontsize=14, pad=10)
ax.axvline(10, color="red", linestyle="--", alpha=0.6, label="Critical path ≈ 10 weeks")
ax.legend(loc="lower right")
ax.grid(axis="x", alpha=0.4)
plt.tight_layout()
plt.savefig("paper_figures/Fig7_Gantt_Timeline.png")
plt.close()
print("✓ Saved: Fig7_Gantt_Timeline.png")

# ------------------------------------------------------------
# 8. Cost breakdown pie chart
# ------------------------------------------------------------
labels = ["Ionic liquid\n(55 %)", "Hardware\n(cold plate + chip + pump)", 
          "DAQ & sensors", "Redox complex + MC"]
sizes = [55.7, 36.7, 7.0, 0.74]
colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
explode = (0.05, 0, 0, 0)

fig, ax = plt.subplots(figsize=(8, 6))
ax.pie(sizes, explode=explode, labels=labels, colors=colors,
       autopct="%1.1f%%", startangle=90, textprops={"fontsize": 11})
ax.set_title("Prototype Cost Breakdown (Total ≈ €1 703)", fontsize=14, pad=15)
plt.tight_layout()
plt.savefig("paper_figures/Fig8_Cost_Pie.png")
plt.close()
print("✓ Saved: Fig8_Cost_Pie.png")

print("\n" + "="*60)
print("All 8 figures saved in ./paper_figures/")
print("="*60)
