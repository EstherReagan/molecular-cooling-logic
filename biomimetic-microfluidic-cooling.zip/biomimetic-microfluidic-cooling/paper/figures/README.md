Place the 8 PNG figures (Fig1_Viscosity_vs_T.png ... Fig8_Cost_Pie.png) in this folder.
